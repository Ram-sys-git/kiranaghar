<?php


if(isset($_POST['b1']) AND !empty($_POST['b1'])){

    $name = $_POST['username'];
    $email = $_POST['email'];
    $msg = $_POST['message'];
    $subject = $_POST['subject'];
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
require "phpmailer/class.phpmailer.php";
require "phpmailer/class.smtp.php";
require "phpmailer/class.phpmaileroauth.php";
require "phpmailer/PHPMailerAutoload.php";


// Load Composer's autoloader
require 'vendor/autoload.php';

// Instantiation and passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = false;                      // Enable verbose debug output
    $mail->isSMTP();                                            // Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 'info@bharatjanss.com';                     // SMTP username
    $mail->Password   = '';                               // SMTP password
    $mail->SMTPSecure = 'ssl';         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
    $mail->Port       = 465;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

    //Recipients
    $mail->setFrom('info@bharatjanss.com', "Job application");
    $mail->addAddress("info@bharatjanss.com", "Job application");     // Add a recipient
   //$mail->addAddress('ellen@example.com');               // Name is optional
   // $mail->addReplyTo('info@example.com', 'Information');
    // $mail->addCC('cc@example.com');
   // $mail->addBCC('bcc@example.com');

     //Attachments
    //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
   // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

    // Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Requirement';
    $mail->Body    = "<table>
                       <tr>
                          <td>name</td>
                            <td>$name</td>
                       </tr>
                       <tr>
                            <td>email</td>
                            <td> $email</td>
                       </tr>
                       <tr>
                            <td>subject</td>
                            <td> $subject</td>
                       </tr>
                       <tr>
                            <td>massage </td>
                            <td> $msg</td>
                       </tr>
                     </table>";
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();

    header('Location: mailthanksmassage.html');
} catch (Exception $e) {
     echo 'Mailer error: ' . $mail->ErrorInfo;
}
}
?>
