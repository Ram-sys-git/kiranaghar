<?php


if(isset($_POST['b1']) AND !empty($_POST['b1'])){

    $name = $_POST['username'];
    $email = $_POST['email'];
    $msg = $_POST['message'];
    $subject = $_POST['subject'];
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
require "class.phpmailer.php";
require "class.smtp.php";
require "class.phpmaileroauth.php";
require "PHPMailerAutoload.php";


// Load Composer's autoloader
require '../vendor/autoload.php';

// Instantiation and passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = false;                      // Enable verbose debug output
    $mail->isSMTP();                                            // Send using SMTP
    $mail->Host       = 'webmail.kiranaghar.co.in';                    // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 'info@kiranaghar.co.in';                     // SMTP username
    $mail->Password   = 'isoft@123';                               // SMTP password
    $mail->SMTPSecure = '';         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
    $mail->Port       = 25;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

    //Recipients
    $mail->setFrom('info@kiranaghar.co.in', "Requirement contact");
    $mail->addAddress("info@kiranaghar.co.in","Requirement contact");     // Add a recipient
   //$mail->addAddress('ellen@example.com');               // Name is optional
   // $mail->addReplyTo('info@example.com', 'Information');
    // $mail->addCC('cc@example.com');
   // $mail->addBCC('bcc@example.com');

     //Attachments
    //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
   // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Requirement';
    $mail->Body    = "<table align=center>
                       <tr>
                          <td>Name</td>
                            <td> $name</td>
                       </tr>
                       <tr>
                            <td>Contact Number</td>
                            <td> $email</td>
                       </tr>
                       <tr>
                            <td>Subject</td>
                            <td> $subject</td>
                       </tr>
                       <tr>
                            <td>Massage </td>
                            <td> $msg</td>
                       </tr>
                     </table>";
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    header("location:../mailthanksmassage.php?id=1");
} catch (Exception $e) {
    echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal("ohh!","something went wrong","warning");';
  echo '}, 1000);</script>';
  header("location:../mailthanksmassage.php?id=2");
}
}

// header('Location: contact_us.html');
?>

