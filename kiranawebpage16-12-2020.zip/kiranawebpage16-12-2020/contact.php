<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title> भारत जन सामग्री सेवा  </title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo_bharat.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <style>
    .section-title h2 {
  font-size: 32px;
  font-weight: bold;
  margin-bottom: 20px;
  padding-bottom: 20px;
  position: relative;
  color:darkblue;
  margin-top: 15px;
}

    .section-title h2::after {
  content: '';
  position: absolute;
  display: block;
  width: 50px;
  height: 0px;
  background: #009961;
  bottom: 0;
}
  </style>

 
</head>

<body>

  <!-- ======= Header ======= -->
 <?php

include 'header.php';
 ?>

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex flex-column justify-content-center">
   <!-- <img src="assets/img/Board.png" width="100%"> -->
    <div class="container" style="display:none">
      <div class="row justify-content-center">
        <div class="col-xl-8">
          <h1> भारत जन सामग्री सेवा </h1>
          <h2></h2>
         <!--  <a href="https://www.youtube.com/watch?v=jDDaplaOz7Q" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a> -->
        </div>
      </div>
    </div>
  </section><!-- End Hero -->

  <div style="padding-bottom:3em">

  <main id="main">

    <!-- ======= About Us Section ======= -->
   
    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title">
          <h2 class="col-xl-12 col-xl-12">
          <span class="col-xl-6 col-xl-6" style="margin-right:400px">
           हमसे संपर्क करें
            </span>
          <span class="col-xl-6 col-xl-6">
सुझाव / शिकायत </span>
        </h2>
          
        </div>
      </div>


      <div class="container">

        <div class="row mt-5">

          <div class="col-lg-4">
            <div class="info">
              <div class="address">
                <i class="ri-map-pin-line"></i>
                <h4>स्थान:</h4>
                <p>माँ इंटरप्राइजेस,<br> 303/304 गोल्ड कॉइन प्लाजा,<br> टावर चौराहा आंध्रा बैंक के ऊपर,<br> इंदौर, मध्य प्रदेश 
                </p>
              </div>

              <div class="email">
                <i class="ri-mail-line"></i>
                <h4>ईमेल:</h4>
                <p>info@bharatjanss.com</p>
              </div>

              <div class="phone">
                <i class="ri-phone-line"></i>
                <h4>कॉल</h4>
                
                <p>+91-0731-3510808</p>
              </div>

            </div>

          </div>

          <div class="col-lg-8 mt-5 mt-lg-0">

            <form  method="post" role="form" action="phpmailer/contact_us.php">
              <div class="form-row">
                <div class="col-md-6 form-group">
                  <input type="text" name="username" class="form-control" id="name" placeholder="आपका नाम" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                  <div class="validate"></div>
                </div>
                <div class="col-md-6 form-group">
                  <input type="text" max="10" class="form-control" name="email" id="email" autocomplete="off" placeholder="आपका मोबाइल नंबर" data-rule="email" data-msg="Please enter a valid email" />
                  <div class="validate"></div>
                </div>
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="विषय" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject"/>
                <div class="validate"></div>
              </div>
              <div class="form-group">
                <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="संदेश"></textarea>
                <div class="validate"></div>
              </div>
              <div class="text-center"><input  name="b1" type="submit" value="मेसेज भेजें" class="btn" style="background:#009961;color:aliceblue"></div>
            </form>

          </div>

        </div>

      </div>

      <div style="margin-top:5%">
      <div style="width: 100%"><iframe width="100%" height="500" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=%20maa%20enterprises%20303/304,%20gold%20coin%20plaza%20%20tower%20chouraha,%20indore%20madhya%20pradesh+(maa%20enterprises)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed">
      </iframe><a href="https://www.google.com/maps/">Draw Map Circle</a></div>
      </div>
    </section><!-- End Contact Section -->

  </main>
</div><!-- End #main -->
  <!-- <div class="container"></div> -->
        </div>
<br>
<?php

include 'footer.php';

?>
  <div id="preloader"></div>
  <a href="#" class="back-to-top"><i class="ri-arrow-up-line"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>