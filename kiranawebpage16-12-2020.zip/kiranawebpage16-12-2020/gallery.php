<?php include 'db.php';
mysqli_set_charset( $con, 'utf8');
$res="SELECT * from image ";
$result = mysqli_query($con, $res);
if(!$result){
    echo $con->error;
  }
  $data  = mysqli_fetch_all($result, MYSQLI_ASSOC);

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title> किराना घर  </title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo_bharat.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="css/baguetteBox.css">
    <style>
body {
    background-color: #fff;
    color: #ddd;
    font-family: Helvetica, Arial, sans-serif;
    margin: 0;
}


h1, h2, h3, footer, .gallery {
    text-align: center;
}

pre {
    width: 340px;
    margin: 0 auto;
    border: dashed 1px #aaa;
    margin-bottom: 10px;
}

@media (max-width: 480px) {
    pre {
        max-width: 98%;
    }
}


.gallery{

    margin-top:10%;
}


.content {
    max-width: 1160px;
    margin: 0 auto;
}

.gallery:after {
    content: '';
    display: block;
    height: 2px;
    margin: .5em 0 1.4em;
    background-image: -webkit-linear-gradient(left, rgba(0, 0, 0, 0) 0%, rgba(77,77,77,1) 50%, rgba(0, 0, 0, 0) 100%);
    background-image: linear-gradient(to right, rgba(0, 0, 0, 0) 0%, rgba(77,77,77,1) 50%, rgba(0, 0, 0, 0) 100%);
}

.gallery img {
    height: 100%;
}

.gallery a {
    width: 300px;
    height: 300px;
    display: inline-block;
    overflow: hidden;
    margin: 4px 6px;
   
    box-shadow: 0 0 4px -1px #000;
}

.ribbon > img {
    position: absolute;
    top: 0;
    right: 0;
    border: 0;
}

@media (max-width: 768px) {
    .sm-hidden {
        display: none;
    }
    .content{

        padding-bottom:5em;
    }
}

/* Highlight.js Tomorrow Night style */
.hljs-comment,.hljs-quote{color:#969896}.hljs-deletion,.hljs-name,.hljs-regexp,.hljs-selector-class,.hljs-selector-id,.hljs-tag,.hljs-template-variable,.hljs-variable{color:#c66}.hljs-tag {color: #f8f8f2}.hljs-built_in,.hljs-builtin-name,.hljs-link,.hljs-literal,.hljs-meta,.hljs-number,.hljs-params,.hljs-type{color:#de935f}.hljs-attr{color:#f0c674}.hljs-addition,.hljs-bullet,.hljs-string,.hljs-symbol{color:#b5bd68}.hljs-section,.hljs-title{color:#81a2be}.hljs-keyword,.hljs-selector-tag{color:#b294bb}.hljs{display:block;overflow-x:auto;background:#1d1f21;color:#c5c8c6;padding:.8em}.hljs-emphasis{font-style:italic}.hljs-strong{font-weight:700}
    </style>
</head>
<body>
<?php include 'header.php'; ?>


<div class="content">
    <h2>OUR STORE IMAGES</h2>

    <pre><code class="js"></code></pre>

    <div class="baguetteBoxOne gallery">
    <?php if(!empty($data)){
		           $i = 1;
		          foreach($data as $value){ ?>
		        
		          
        <a href="login/asset/uploads/<?php echo $value['image'] ?>" data-caption="bharatjanss">
            <img src="login/asset/uploads/<?php echo $value['image'] ?>" alt="kiranaghar" style="width:80%">
        </a>
        <?php } }?>
      
    </div>
    <?php include "footer1.php"; ?>
    
<script src="js/baguetteBox.js" async></script>
<script src="js/highlight.min.js" async></script>
<!--[if lt IE 9]>
<script>
var oldIE = true;
</script>
<![endif]-->
<script>
window.onload = function() {
    baguetteBox.run('.baguetteBoxOne');
    baguetteBox.run('.baguetteBoxTwo');
    baguetteBox.run('.baguetteBoxThree', {
        animation: 'fadeIn',
        noScrollbars: true
    });
    baguetteBox.run('.baguetteBoxFour', {
        buttons: false
    });
    baguetteBox.run('.baguetteBoxFive', {
        captions: function(element) {
            return element.getElementsByTagName('img')[0].alt;
        }
    });

    if (typeof oldIE === 'undefined' && Object.keys) {
        hljs.initHighlighting();
    }

    var year = document.getElementById('year');
    year.innerText = new Date().getFullYear();
};
</script>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
</body>
</html>