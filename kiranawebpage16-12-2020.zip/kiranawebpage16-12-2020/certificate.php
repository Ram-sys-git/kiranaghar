w<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title> भारत जन सामग्री सेवा  </title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo_bharat.png" rel="icon">
  <link href="assets/img/logo_bharat.png" rel="logo_bharat">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
 

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
  .carousel-inner .item img{

height:800px;
}


@media(max-width:768px){
.carousel-inner .item img{

height:400px;
}

}
</style>

</head>
<?php

include 'header.php';
?>
<div class="a1" style="padding-top:9em;">
</div>
<h2 style="text-align:center;">प्रपत्र</h2>


<div class="container">
   
   <div id="Carousel" class="carousel slide" data-ride="carousel">
     <!-- Indicators -->
     <ol class="carousel-indicators">
       <li data-target="#Carousel" data-slide-to="0" class="active"></li>
       <li data-target="#Carousel" data-slide-to="1"></li>
       <li data-target="#Carousel" data-slide-to="2"></li>
     </ol>
 
     <!-- Wrapper for slides -->
     <div class="carousel-inner">
       <div class="item active">
         <img src="assets/img/certificate.jpg" alt="kiranaghar" style="width:100%;">
       </div>
 
       <div class="item">
         <img src="assets/img/certificate2.jpg" alt="bharatjanss" style="width:100%;">
       </div>
     
       <div class="item">
         <img src="assets/img/newcertificate.jpg" alt="kiranaghar" style="width:100%">
       </div>
     </div>
 
     <!-- Left and right controls -->
     <a class="left carousel-control" href="#Carousel" data-slide="prev">
       <span class="glyphicon glyphicon-chevron-left"></span>
       <span class="sr-only">Previous</span>
     </a>
     <a class="right carousel-control" href="#Carousel" data-slide="next">
       <span class="glyphicon glyphicon-chevron-right"></span>
       <span class="sr-only">Next</span>
     </a>
   </div>
 </div>
 <br/>


<?php

include 'footer1.php';

?>

<script src="assets/js/main.js"></script>
</body>
</html>
