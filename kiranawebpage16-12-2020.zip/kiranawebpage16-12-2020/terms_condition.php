<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title> भारत जन सामग्री सेवा  </title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo_bharat.png" rel="icon">
  <link href="assets/img/logo_bharat.png" rel="logo_bharat">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  
</head>

<body>

  <?php

include 'header.php';
?>

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex flex-column justify-content-center">
 <!--    <img src="assets/img/Board.png" width="100%"> -->
    <div class="container" style="display:none">
      <div class="row justify-content-center">
        <div class="col-xl-8">
          <h1> भारत जन सामग्री सेवा </h1>
          <h2></h2>
         <!--  <a href="https://www.youtube.com/watch?v=jDDaplaOz7Q" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a> -->
        </div>
      </div>
    </div>
  </section><!-- End Hero -->

  <div style="padding-bottom:13em">

  <main id="main">

    <!-- ======= About Us Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="section-title">
          <h2>नियम व शर्तें</h2>
          <p>
            
            
          <ol style="font-size:20px;"> <li>भारत जन सामग्री सेवा (वार्ड स्तर/ पंचायत स्तर) को सामग्री किराना भंडार (जिला स्तर) शहरी/ ग्रामीण द्वारा उपलब्धता कराई जाएगी |</li>
              <li> भारत जन सामग्री सेवा./ किराना भंडार सामग्री की निश्चिंत तय मात्रा में स्टॉक होना वह उससे कम होने पर केंद्र व भंडार व किराना को अलर्ट आएगा |</li>
              <li> भारत जन सामग्री सेवा. पर सदस्य संख्या 2100 निश्चिंत रहेगी |</li>
             <li> भारत जन सामग्री सेवा. तक किराना भंडार व किराना भंडार तक किराना महाभंडार व किराना महाभंडार तक केंद्र द्वारा सामग्री पहुंचाई जाएगी | ट्रांसपोर्टेशन का व्यय सभी को FOR होगा |</li>
             <li> सामग्री पहुंचाने का समय प्रथम बार में 15 दिन व उसके बाद 7 दिन तय होगा | यदि तय समय पर सामग्री भुगतान प्राप्ति होने पर भी नहीं पहुंचती है तो ऊपर वाले स्तर को आगे के स्तर का केंद्र द्वारा निर्धारित व्यय वहन करना होगा |</li>
             <li> भारत जन सामग्री सेवा. व किराना भंडार को प्रतिमाह पारश्रमिक के रूप में A/B/C/D ग्रुप की सामग्री के कुल   आवर्त पर तय प्रतिशत पारश्रमिक के रूप में केंद्र द्वारा दिया जाएगा  | </li>
              <li> उक्त पारश्रमिक से केंद्र द्वारा प्रबंधकिय शुल्क के रूप में व TDS के परसेंटेज काटकर भुगतान बैंक अकाउंट में RTGS प्रतिमाह के प्रथम सप्ताह में कर दिया जाएगा </li>
             <li> भारत जन सामग्री सेवा./भंडार या तो सीधे या किसी प्रस्तावक द्वारा बनाए जाएंगे | उक्त कार्य के लिए प्रस्तावक को प्रतिमाह भारत जन सामग्री सेवा./ भंडार के पारश्रमिक के भुगतान का  परसेंटेज कमीशन के रूप में दिया जाएगा | प्रस्तावक का एक यूनिक कोड केंद्र द्वारा दिया जाएगा| जिससे वह भारत जन सामग्री सेवा. भंडार बनेगा | तथा प्रस्तावित प्रतिमाह में तीन बार उक्त भारत जन सामग्री सेवा./भंडार की रिपोर्ट भी केंद्र को ऑनलाइन भेजेगा |</li>
             <li> विशेष परिस्थितियों में केंद्र किसी भी भारत जन सामग्री सेवा./भंडार को ब्लॉक कर सकता है | कार्य करने से रोक सकता है | तथा समस्या हल होने पर फिर ओपन कर सकता है |</li>
             <li> किराना भंडार/घर के लिए भी बोनस प्वाइंट सिस्टम केंद्र द्वारा तय किया जाएगा | जिस पर  उन्हें उपहार प्राप्त होंगे |</li>
             <li> किराना भंडार/घर पर उपलब्ध सामग्री का विक्रय मुख्य केंद्र तय करेगा सामान्यता सामग्री अनुसार मूल्य प्रति सप्ताह सामान्यता विशेष परिस्थिति में कभी भी केंद्र द्वारा परिवर्तन योग्य होगा |</li> </ol>

          </p>
        </div>

       <!--  <div class="row content">
          <div class="col-lg-6">
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
              magna aliqua.
            </p>
            <ul>
              <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat</li>
              <li><i class="ri-check-double-line"></i> Duis aute irure dolor in reprehenderit in voluptate velit</li>
              <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat</li>
            </ul>
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0">
            <p>
              Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
              velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
              culpa qui officia deserunt mollit anim id est laborum.
            </p>
            <a href="#" class="btn-learn-more">Learn More</a>
          </div>
        </div> -->

      </div>
    </section><!-- End About Us Section -->

    <!-- ======= Services Section ======= -->
   

  </main>
</div><!-- End #main -->
  <!-- <div class="container"></div> -->

  <?php


include 'footer.php';
?>


  <div id="preloader"></div>
  <a href="#" class="back-to-top"><i class="ri-arrow-up-line"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>