<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title> भारत जन सामग्री सेवा  </title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo_bharat.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

 
</head>

<body>

 <?php

include 'header.php';
?>

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex flex-column justify-content-center">
    <!-- <img src="assets/img/Board.png" width="100%"> -->
    <div class="container" style="display:none">
      <div class="row justify-content-center">
        <div class="col-xl-8">
          <h1> भारत जन सामग्री सेवा </h1>
          <h2></h2>
         <!--  <a href="https://www.youtube.com/watch?v=jDDaplaOz7Q" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a> -->
        </div>
      </div>
    </div>
  </section><!-- End Hero -->

<!--     
  <div style="padding-bottom:13em"> -->
</div><!-- End #main -->
  <!-- <div class="container"></div> -->
  <section id="contact" class="contact">
    <div class="container">

      <div class="section-title">
        <h2 class="col-md-6 col-xl-12">
        <span class="col-md-6 col-xl-6" style="text-align:center">
          आवेदन करे 
          </span>
        
      </h2>
        
      </div>
    </div>

  <div class="container">

    <div class="row ">

      
      <div class="col-lg-12  mt-lg-0" style="padding-bottom:10em;">

        <form  method="post" role="form" action="phpmailer/contact_us.php">
          <div class="form-row">
            <div class="col-md-6 form-group">
              <input type="text" name="username" class="form-control" id="name" placeholder="आपका नाम" data-rule="minlen:4" data-msg="Please enter at least 4 chars" required />
              <div class="validate"></div>
            </div>
            <div class="col-md-6 form-group">
              <input type="text" max="10" class="form-control" name="email" id="email" placeholder="आपका मोबाइल नंबर" autocomplete="off" data-rule="email" data-msg="Please enter a valid email" required/>
              <div class="validate"></div>
            </div>
          </div>
          <div class="form-group">
            <input type="text" class="form-control" name="subject" id="subject" placeholder="विषय" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" required/>
            <div class="validate"></div>
          </div>
          <div class="form-group">
            <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="संदेश"></textarea>
            <div class="validate"></div>
          </div>
          <div class="text-center"><input  name="b1" type="submit" value="मेसेज भेजें" class="btn" style="background:#009961;color:aliceblue"></div>
        </form>

      </div>

    </div>

  </div>
  </section>
  


<br>
  <?php
include 'footer.php';

?>


  <div id="preloader"></div>
  <a href="#" class="back-to-top"><i class="ri-arrow-up-line"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>