<?php
require_once('/db.php');
mysqli_set_charset( $con, 'utf8');
$sql = "SELECT product_name,min_qty,product_attributes.product_price,sell_price,regular_price,product_description FROM product LEFT JOIN product_attributes ON product.id = product_attributes.product_id ORDER by sequence ASC";
$result = mysqli_query($con, $sql);
if(!$result){
  echo $con->error;
}

// Fetch all
$data  = mysqli_fetch_all($result, MYSQLI_ASSOC);
?> 
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <title> भारत जन सामग्री सेवा  </title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo_bharat.png" rel="icon">
  <link href="assets/img/logo_bharat.png" rel="logo_bharat">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
<style>
  .portfolio-item .info{
    background-color:#000080;
  color:#fff;
  text-align: center;
  font-weight: 600;
  height:52px;
  
  
  
  }
  .portfolio-item .info h6 {
    padding-top:5px;
    font-size: 14px;
    font-family:Arial, Helvetica, sans-serif;
    
  }
  .portfolio-item .info p{
    font-size: 14px;
    margin-top:-4px;
    
  }

  
</style>
</head>

<body>

  <!-- ======= Header ======= -->
  <?php include "header.php"; ?>
 <!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex flex-column justify-content-center">
    <img src="" width="100%">
    <div class="container" style="display:none">
      <div class="row justify-content-center">
        <div class="col-xl-8">
          <h1> भारत जन सामग्री सेवा  </h1>
          <h2></h2>
         <!--  <a href="https://www.youtube.com/watch?v=jDDaplaOz7Q" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a> -->
        </div>
      </div>
    </div>
  </section><!-- End Hero -->

    <section id="portfolio" class="portfolio">
      <div class="container">

        <div class="section-title">
          <h2> सभी सामग्री</h2>
         <!--  <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p> -->
        </div>
        </section></div>
      </section>
    <div class="container" class="table-responsive" style="overflow-x:auto"></div>            
      <table class="table table-bordered" style="text-align:center;margin-bottom:13em;font-size:16px;table-layout:fixed;word-wrap:break-word">
        <thead>
          <tr>
            <th>S.no</th>
            <th>Items</th>
            <th>सामग्री </th> 
           <th>अधिकतम मात्रा </th>
            <th>MRP</th>
            <th>Selling Price (Member)</th>
            <th>Selling Price (Non-Member)</th>
          </tr>
        </thead>
        <tbody>
          <?php if(!empty($data)){
           $i = 1;
          foreach($data as $value){ ?>
            <tr>
            <td><?php echo $i; ?>.</td>
            <td><?php echo $value['product_name']; ?></td>
            <td><?php echo $value['product_description']?></td>
            <td><?php echo $value['min_qty']; ?></td>
            <td><?php echo $value['product_price']; ?>/- </td>
            <td><?php echo $value['sell_price']; ?>/-</td>
            <td><?php echo ($value['regular_price'] >0? $value['regular_price'] :0) ; ?>/-</td>
          </tr>
        <?php  $i++; } 
        } ?>
          
                                      
                                           
                                          
                                        
                                           <tr>
                                       
                                            <td style="color:red;font-size:20px;" colspan="7">मूल्य प्रति सोमवार परिवर्तन योग्य है ।</td> 
                                        
                                          </tr>

                                        
                                       
        </tbody>

      </table>
      



    </div>

   
 
        
</div><!-- End #main -->
  <!-- <div class="container"></div> -->
  
 <?php include "footer1.php"; ?>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>