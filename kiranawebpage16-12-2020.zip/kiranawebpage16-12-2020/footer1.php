<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title> भारत जन सामग्री सेवा  </title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo_bharat.png" rel="icon">
  <link href="assets/img/logo_bharat.png" rel="logo_bharat">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
<style>
 @media(max-width:768px){

   .footer .row{

     height:5em;
   }
 }
 
  @media (max-width:768px){

.footer .col-md-7{

  text-align:center;

}

}
@media (max-width:768px){

.footer .col-md-5{
   
  padding-right:20%;
}

}

    </style>

</head>
<div class="footer row" style="margin-left:0%;">
    <div class="col-md-7" style="padding-top:.4em;font-size:16px;">
      कॉपीराइट <strong> भारत जन सामग्री सेवा </strong>सभी अधिकार सुरक्षित <br>
      Designed by <a  style="color:seashell;"  href="http://isoftzone.com/index.php">i-SOFTZONE</a>
    </div>
    <div class="col-md-5" style="text-align:right;padding-top:.4em;font-size:16px;">
      Contact :- +91-731-3510808<br>
      E-mail :- info@bharatjanss.com
    </div>
  
</div> 

