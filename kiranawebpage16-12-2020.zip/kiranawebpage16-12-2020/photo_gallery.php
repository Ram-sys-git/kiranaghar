<?php
require_once('/db.php');
mysqli_set_charset( $con, 'utf8');
$sql = "SELECT product_image,group_name,product_name,min_qty,product_attributes.product_price,sell_price ,product_description FROM product LEFT JOIN product_attributes ON product.id = product_attributes.product_id LEFT JOIN group_masters ON product.group_id= group_masters.id WHERE product.status = '1' ORDER by product.sequence ASC"  ;
$result = mysqli_query($con, $sql);

if(!$result){
  echo $con->error;
}

// Fetch all
$data  = mysqli_fetch_all($result, MYSQLI_ASSOC);


$csql   = "SELECT * FROM group_masters";
$cresult = mysqli_query($con, $csql);
if(!$cresult){
  echo $con->error;
}

// Fetch all
$cdata  = mysqli_fetch_all($cresult, MYSQLI_ASSOC);
?> 

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title> किराना घर  </title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo_bharat.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <style>
  .portfolio-item .info{
    background-color:#000080;
  color:#fff;
  text-align: center;
  font-weight: 600;
  height:52px;
  width:100%;
  
  
  
  }
  .portfolio-item .info h6 {
    padding-top:5px;
    font-size: 14px;
    font-family:Arial, Helvetica, sans-serif;
    
  }
  .portfolio-item .info p{
    font-size: 14px;
    margin-top:-4px;
    
  }

  .img_height { 
    width: 100% !important;
    height: 250px !important;
   }

  
</style>

  <!-- =======================================================
  * Template Name: KnightOne - v2.1.0
  * Template URL: https://bootstrapmade.com/knight-simple-one-page-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
    <?php include "header.php"; ?>
  <!-- End Header -->

  <!-- ======= Hero Section ======= --><!-- End Hero -->

  <div style="padding-bottom:13em">

  <main id="main">

    <!-- ======= About Us Section ======= -->
   
    <section id="portfolio" class="portfolio">
      <div class="container">

        <div class="section-title">
          <h2> सभी सामग्री</h2>
         <!--  <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p> -->
        </div>

        <div class="row">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">सभी </li>

              <?php if(!empty($cdata)){
		           $i = 1;
		          foreach($cdata as $cvalue){ ?>
		          	<li data-filter=".<?php echo $cvalue['group_name'] ?>"><?php echo $cvalue['group_name']; ?></li>
		          <?php } }?>
              <!-- <li data-filter=".filter-app">मसाले</li>
              <li data-filter=".filter-card">दालें </li>
              <li data-filter=".filter-soft">ब्रांडेड सामग्री </li>
              <li data-filter=".filter-web">अन्य सामग्री</li> -->
            </ul>
          </div>
        </div>

        <div class="row portfolio-container">

          
           <?php if(!empty($data)){
           	foreach ($data as $key => $value) { 
           		 $images  = @unserialize($value['product_image']); 
                 $images  = !empty($images)?$images:[];
                 
           		?>
           		<div class="col-lg-3 col-md-6 portfolio-item <?php echo $value['group_name']; ?>">
		            <img src="<?php echo  isset($images[0])? "login/asset/uploads/$images[0]":'login/asset/default_images/no_image.png'; ?>" class="img-fluid max-width: 100% img_height" >
		            <div class="info" container>
		              <h6><?php echo $value['product_description']; ?> </h6>
		              <p> &nbsp;<s>Rs.<?php echo $value['product_price']; ?>/- </s><span></span>  Rs.<?php echo $value['sell_price']; ?>/-</p>
		              
		              </div>
		          </div>
           <?php 	}
           } ?>

          
         

        </div>
      </div>
      
    </section><!-- End Portfolio Section -->

    <!-- ======= Pricing Section ======= -->
    <!-- End Contact Section -->

  </main>
</div><!-- End #main -->
  <!-- <div class="container"></div> -->

 <?php include "footer1.php"; ?>
  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>