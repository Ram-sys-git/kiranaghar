<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title> भारत जन सामग्री सेवा  </title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo_bharat.png" rel="icon">
  <link href="assets/img/logo_bharat.png" rel="logo_bharat">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: KnightOne - v2.1.0
  * Template URL: https://bootstrapmade.com/knight-simple-one-page-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

 <?php

include 'header.php';

?>

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex flex-column justify-content-center">
   <!--  <img src="assets/img/Board.png" width="100%"> -->
    <div class="container" style="display:none">
      <div class="row justify-content-center">
        <div class="col-xl-8">
          <h1> भारत जन सामग्री सेवा </h1>
          <h2></h2>
         <!--  <a href="https://www.youtube.com/watch?v=jDDaplaOz7Q" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a> -->
        </div>
      </div>
    </div>
  </section><!-- End Hero -->

  <div style="padding-bottom:13em">

  <main id="main">

    <!-- ======= About Us Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="section-title">
          <h2>संचालक बनने की प्रक्रिया</h2>
          <ol style="font-size:20px">
          &nbsp;&nbsp;&nbsp;&nbsp; किराना घर संचालक बनने के लिए निर्धारित प्रक्रिया में सभी आवश्यक पत्रों की फोटो कॉपी के साथ घोषणा व आवेदन को स्वहस्ताक्षरीन कर 4 प्रतियो में जमा कराना होगा |  <br/> <br/> 
            &nbsp;&nbsp;&nbsp;&nbsp;हमारे द्वारा सभी मापदंडों की जांच के उपरांत आवेदक चयन कर उसे बुलाकर अनुबंध की शर्तें व कार्य समझा कर अनुबंध कर किराना घर का संचालन तथा स्थान विशेष पर करने का प्रमाण पत्र व अनुमति प्रदान की जाएगी |<br/><br/>
            &nbsp;&nbsp;&nbsp;&nbsp;अनुबंध करने के लिए प्रथम ₹ 160000/- रुपए का भुगतान आवेदक को करना होगा | इसके एवज  में लगभग ₹ 200000/- रुपए बाजार मूल्य (MRP) की सामग्री हमारे द्वारा किराना घर संचालन करने के लिए आवेदक को उपलब्ध कराई जाएगी | आवेदक की स्वयं की या किराए की दुकान न्यूनतम 10 x 10  होनी चाहिए | <br/><br/>
            आवेदक को किराना घर प्रारम्भ करने के लिए आवश्यकताए -<br/><br/>

            <li> 10 X 10  दुकान </li>
             <li> गुमाश्ता लाइसेंस </li>
            <li> FSSAI  लाइसेंस </li>
            <li> बैंक खाता </li>
            <li> प्रिंटर </li>
            <li> कंप्यूटर  / लैपटॉप / स्मार्टफोन </li>         
               <li>तोल कांटा इलेक्ट्रॉनिक </li>
            <li>सामग्री रखने की अलमारियां </li>
            <li> काउंटर </li>
            <li> हमारी डिजाइन का बोर्ड|</li><br/>

             किराना घर संस्था को प्राप्त परिश्रमिक <br/><br/>
             किराना घर को हमारे द्वारा प्रतिमाह किये गए कुल विक्रय पर सामग्री श्रेणी अनुसार परिश्रमिक अगले माह के प्रथम सप्ताह में देय होगा | <br/><br/>
             <table class="table table-striped">
  <thead>
    <tr>
      <th>सामग्री श्रेणी</th>
      <td>A</td>
      <td>B</td>
      <td>C</td>
      <td>D</td>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>परिश्रमिक </th>
      <td>2%</td>
      <td>4%</td>
      <td>6%</td>
      <td>8%</td>
    </tr>
    <tr>
    
  </tbody>
</table>

             <!-- &nbsp;&nbsp; सामग्री श्रेणी &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;       A &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;         B  &nbsp;  &nbsp;&nbsp; &nbsp;&nbsp;       C        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;       D  <br/><br/>
             &nbsp;&nbsp; परिश्रमिक   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;      2%       &nbsp;&nbsp;&nbsp;       4%    &nbsp;&nbsp;&nbsp;&nbsp;      6%    &nbsp;&nbsp;&nbsp;&nbsp;        8%  <br/><br/> -->
             &nbsp;&nbsp;&nbsp;&nbsp;सामग्री श्रेणी माह में पूर्व निर्धारित होगी व सूची किराना घर संचालक को पहले से ज्ञात होगी| वार्ड व पंचायत में जनसंख्या अनुसार कहीं एक ही किराना घर खोला जाएगा | तथा प्रत्येक किराना घर पर सदस्य संख्या 2100 निश्चित रहेगी | 2100 सदस्य पूरे होने पर वार्ड में दूसरा किराना घर खोला जा सकता है |<br/>
            &nbsp;&nbsp;&nbsp;&nbsp; जो सदस्य जिस किराना घर प्रथम बार सम्मिलित हो गया वह सिर्फ किन्हीं विशेष परिस्थितियों में ही हमारी आज्ञा से ही किराना घर बदल पाएगा अन्यथा किराना घर पर एक बार सम्मिलित होने के बाद सदस्य अन्य किराना घर पर से समान क्रय नहीं कर सकता है | किराना घर संचालन के समस्त व्यय संचालक को अपने परिश्रमिक से ही समायोजित करना होगा हमारे द्वारा अन्य कोई राशि किराना घर संचालक को नहीं दी जाएगी |

             <ol>
            
            <!-- &nbsp;&nbsp;&nbsp;&nbsp; भारत जन सामग्री सेवा आपके घर का किराना हर वार्ड व पंचायत में खोले जाएंगे | जहां सूचीबद्ध सामग्री कम दाम पर एक निश्चित न्यूनतम राशि में क्रय करने के लिए उपलब्ध होगी | जनसामान्य को सामग्री ‘भारत जन सामग्री सेवा ’ से क्रय करने के पूर्व अपना सदस्यता कार्ड ‘भारत जन सामग्री सेवा ’ से एक तय शुल्क देकर बनवाना होगा |
            यह कार्ड एक परिवार का एक ही बनेगा कार्ड बनवाने के लिए परिवार की समग्र आईडी अनिवार्य है | कार्ड बनवाने के पूर्व एक आवेदन फॉर्म भी भरना होगा | उक्त कार्ड पर प्रशासनिक व प्रबंधकीय शुल्क के रूप में एक तय शुल्क प्रतिमाह देना होगा |
            प्रत्येक कार्ड धारी सदस्य तय की गई मात्रा व संख्या में ही सामग्री का क्रय कर सकेगा तय मात्रा से ज्यादा सामग्री किसी भी परिस्थिति में नहीं दी जाएगी | प्रत्येक वार्ड व पंचायत स्तर के ‘भारत जन सामग्री सेवा ’ पर एक निश्चित संख्या में ही कार्ड बनेंगे तथा जो कार्ड एक भारत जन सामग्री सेवा पर बन गया वह कार्ड उसी भारत जन सामग्री सेवा से सामग्री क्रय करेगा | अन्य भारत जन सामग्री सेवा से उसे सामग्री नहीं मिलेगी | <br/>
            &nbsp;&nbsp;&nbsp;&nbsp; नोट : <br/>
            <li> भारत जन सामग्री सेवा सदस्य बनाना - सामग्री क्रय करने के पूर्व भारत जन सामग्री सेवा सदस्यता कार्ड बनवाना अनिवार्य ह</li>
             <li> किराना का सदस्यता कार्ड बनवाने के लिए सदस्यता कार्ड के लिए आवेदन देने साथ कार्ड शुल्क रु 90 देना होगा | आवेदन शुल्क प्राप्त होने के सात दिवस (कार्यकालीन दिवस) के अंदर प्रेषित कर दिया जाएगा सदस्यता कार्ड प्राप्त कर व्यक्ति भारत जन सामग्री सेवा से सामग्री क्रय कर सकेगा |</li>
            <li> भारत जन सामग्री सेवा सदस्यता कार्ड पूरे परिवार के लिए होगा व इसे बनवाने के लिए परिवार समग्र आईडी अनिवार्य होगी </li>
            <li> भारत जन सामग्री सेवा सदस्यता कार्ड का प्रतिमाह शुल्क रु 40/- (प्रबंधकिय शुल्क) सदस्य द्वारा देय होगा | </li>
            <li> हमारे द्वारा हमारे सदस्यों को बाजार मूल्य से कम मूल्य या उचित मूल्य पर सामग्री उपलब्ध कराई जा रही है, परंतु इसकी क्रय करने की मात्रा संख्या प्रतिमाह निश्चित की गई है, सदस्य इस निश्चित संख्या मात्रा से ज्यादा किसी भी परिस्थिति में क्रय कर पाएंगे |</li>
            <li> हमारे द्वारा भारत जन सामग्री सेवा सदस्यों को अत्यंत किफायती मूल्य पर सामग्री क्रय करने के लिए उपलब्ध कराई जाती है, हम सामग्री के मूल्य को कम रखने का अत्यधिक प्रयास करते हैं, तथापि बाजार में पहले से उपलब्ध पुराना स्टॉक, सामग्री की गुणवत्ता, बाजार के उतार- चढ़ावो के कारण कुछ सामग्रियों के मूल्यों में कमी बढ़ोतरी सदस्यों को महसूस हो सकती है |</li>         
               <li> बाजार के उतार- चढ़ावो के कारण सामग्री का मूल्य हमेशा साप्ताहिक परिवर्तनशील रहेगा |</li>
            <li> ब्रांडेड सामग्री के ब्रांड उपलब्धता व समय के अनुसार परिवर्तित होते रहेंगे |</li>
            <li> प्रतिमाह प्रत्येक सदस्य को एक बार में ही अपनी आवश्यकता की सामग्री क्रय करना होगा अन्य शब्दों में किराना कार्ड से 1 माह में एक बार ही सामग्री क्रय की जा सकेगी | </li>
            <li> क्रय बिल की न्यूनतम राशि अनिवार्य रूप से रू 2000 की रहेगी |</li>
             <li> भारत जन सामग्री सेवा सदस्य सामग्री सूची से अपनी आवश्यकता की सामग्री चुनकर उसे निश्चित संख्या में क्रय कर सकते हैं | </li>
            <li> क्रय करने के लिए सदस्य भारत जन सामग्री सेवा संचालक को अपना सदस्य कार्ड दिखायेगा | उक्त कार्ड नंबर पैसे से ही भारत जन सामग्री सेवा संचालक अपने ऐप में अंकित करेगा सदस्य के मोबाइल नंबर पर एक OTP आएगा, OTP भारत जन सामग्री सेवा संचालक द्वारा अंकित करने पर सामग्री क्रय करने की प्रक्रिया प्रारंभ हो सकेगी | क्रय पूर्ण होने पर भुगतान के पश्च्यात बिल की कॉपी सदस्य के वाहट्सएप्प पर आएगी व मांगने पर प्रिंट भी मिलेगा | </li> <ol>
          -->
        </div>

       <!--  <div class="row content">
          <div class="col-lg-6">
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
              magna aliqua.
            </p>
            <ul>
              <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat</li>
              <li><i class="ri-check-double-line"></i> Duis aute irure dolor in reprehenderit in voluptate velit</li>
              <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat</li>
            </ul>
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0">
            <p>
              Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
              velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
              culpa qui officia deserunt mollit anim id est laborum.
            </p>
            <a href="#" class="btn-learn-more">Learn More</a>
          </div>
        </div> -->

      </div>
    </section><!-- End About Us Section -->

    <!-- ======= Services Section ======= -->
   

  </main>
</div><!-- End #main -->
  <!-- <div class="container"></div> -->

 <?php

include 'footer.php';
?>


  <div id="preloader"></div>
  <a href="#" class="back-to-top"><i class="ri-arrow-up-line"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>