<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title> भारत जन सामग्री सेवा  </title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo_bharat.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  
</head>

<body>

  <!-- ======= Header ======= -->
 <?php
include 'header.php';

?>
  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex flex-column justify-content-center">
  <!--   <img src="assets/img/Board.png" width="100%"> -->
  </section><!-- End Hero -->

  <div style="padding-bottom:13em">
    <main id="main">

    <!-- ======= About Us Section ======= -->
    <section id="services" class="services">
      <div class="container">

        <div class="section-title">
          <h2>उद्देश्य वह लक्ष्य</h2>
          <p><!-- Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas. -->
               <!--  हमारे उद्देश्य व लक्ष्य डाउनलोडस <br/><br>
                1. आवेदन संचालकता कार्ड <br>
                2. आवेदन किराना भंडार/भारत जन सामग्री सेवा  <br> -->

                &nbsp;&nbsp;&nbsp;&nbsp;वर्तमान में हमारे देश में जन सामान्य सभी वर्गों के खासकर मध्यम वर्ग व अन्य वर्ग के घर का बजट अस्त-व्यस्त है,
                प्रत्येक परिवार को अपना जीवन यापन अपनी जरूरतों में बड़ी कटौती कर करना पड़ रहा है| 
                जीवन यापन में कई जरूरतों की कटौती करने के बाद भी ‘घर का राशन’ एक ऐसी मद है, जहां किसी भी प्रकार की कटौती लगभग असंभव है| ‘घर का किराना’ में प्रतिदिन बढ़ती व कमर तोड़ती महंगाई की मार पूरे परिवार के बजट व जीवन यापन की अनिवार्य आवश्यकताओं को बुरी तरह प्रभावित कर रही है| यह तो एक पक्ष हो गया परंतु ‘घर का किराना’ जहां उत्पादित होता है अर्थात हमारा उत्पादक वर्ग व किसान भी कम आमदनी व सामग्री के कम दाम मिलने से परेशान व नाराज हैं| तो प्रश्न यह उठता है, कि एक ओर जनसामान्य के लिए महंगाई है, और दूसरी ओर उत्पादक व किसान वर्ग भी अपने उत्पाद के कम दाम मिलने से नाराज है, तो इस बीच का पैसा कहां जाता है? कैसे उत्पादक, किसान से सस्ते दाम की सामग्री जनसामान्य तक पहुंचते पहुंचते महंगे दाम में परिवर्तित हो जाती है ? इन्हीं और इनके जैसे प्रश्नों का उत्तर कुछ शहरों में बड़े व प्रतिष्ठित ब्रांड के स्टोर्स जैसे डी मार्ट , जिओस्टोर, बेस्ट प्राइस, ऑन डोर से प्राप्त हो जाता है| जहां बड़ी मात्रा में उत्पादक व किसानों से सीधे सामान खरीद कर उन्हें जनसामान्य को कुछ कम दाम पर उपलब्ध करा दिया जाता है, परंतु हमारे देश की परिस्थिति व हमारे देश की जनसंख्या का वितरण देखते हुए एक बड़ा वर्ग इसके प्रभाव सीमा से वंचित रह जाता है, ये स्टोर्स हमारे देश के ग्रामीण वर्ग,निम्न मध्यम वर्ग व निम्न वर्ग की पहुच से अभी भी बहुत दूर हैं| <br/>
                &nbsp;&nbsp;&nbsp;&nbsp;भारत के ग्रामीण वर्ग, निम्न मध्यम वर्ग व निम्न वर्ग जहां हमारे देश का 65% से 75% हिस्सा इस वर्ग का प्रतिनिधित्व करता है| उन्हीं भारतवासियों की ‘घर का राशन’ के व्यय की समस्या को एक सीमा तक दूर कर उक्त वर्ग के हमारे देशवासियों को महंगाई की मार से राहत दिलाने का एक प्रयास, हमारे द्वारा, भारत जन सामग्री सेवा की ध्वजा के तले ‘माँ इंटरप्राइजेस’ द्वारा वार्ड व पंचायत स्तर पर ‘ किराना घर ’ के रूप में किया जा रहा है| ‘माँ इंटरप्राइजेस’ में हमारी कोशिश होगी कि हम ‘घर का किराना’ खर्च 30% से 40% तक कम कर सकें| इसके अन्तर्गत हमारा उद्देश्य  ‘घर का किराना ’ में लगने वाली आवश्यक सामग्री को सूचीबद्ध कर अच्छी गुणवत्ता व कम दाम पर एक निश्चित मात्रा अथवा संख्या में जन सामान्य के घर के निकटतम स्थान पर उपलब्ध कराना है| <br/>
<!-- डाउनलोडस <br/>
1. आवेदन संचालकता कार्ड <br/>
2. आवेदन किराना भंडार/भारत जन सामग्री सेवा  <br/> -->
 <br/>
       </p>

        </div>

       <!--  <div class="row content">
          <div class="col-lg-6">
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
              magna aliqua.
            </p>
            <ul>
              <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat</li>
              <li><i class="ri-check-double-line"></i> Duis aute irure dolor in reprehenderit in voluptate velit</li>
              <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat</li>
            </ul>
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0">
            <p>
              Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
              velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
              culpa qui officia deserunt mollit anim id est laborum.
            </p>
            <a href="#" class="btn-learn-more">Learn More</a>
          </div>
        </div> -->

      </div>
    </section>
 </div><!-- End #main -->
  <!-- <div class="container"></div> -->

 <?php
include 'footer.php';
 ?>


  <div id="preloader"></div>
  <a href="#" class="back-to-top"><i class="ri-arrow-up-line"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>