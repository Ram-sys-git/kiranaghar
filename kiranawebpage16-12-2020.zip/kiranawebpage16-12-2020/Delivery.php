<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title> भारत जन सामग्री सेवा  </title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
   <link href="assets/img/logo_bharat.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
<style>

  
@media (max-width:768px){
  .container-img{{


    
    
  }

}


  }
  </style>
 
</head>

<body>

  <!-- ======= Header ======= -->
 <?php

include 'header.php';

?>
  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex flex-column justify-content-center">
   <!--   <img src="assets/img/Board.png" width="100%"> -->
    <div class="container" style="display:none">
      <div class="row justify-content-center">
        <div class="col-xl-8">
          <h1> भारत जन सामग्री सेवा </h1>
          <h2></h2>
         <!--  <a href="https://www.youtube.com/watch?v=jDDaplaOz7Q" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a> -->
        </div>
      </div>
    </div>
  </section><!-- End Hero -->

  <div style="padding-bottom:13em">

  <main id="main">

    <!-- ======= About Us Section ======= -->
   <!-- End Portfolio Section -->

    <!-- ======= Pricing Section ======= -->
    <section id="pricing" class="pricing">
      <div class="container" style="width:auto">

        <div class="section-title">
          <h2>वितरण प्रणाली</h2>
          <p>

            <br/> <br/>
            इस योजना हेतु त्रि स्तरीय वितरण प्रणाली तय की गई है|</p> <br/><br/><br/><br/>

            <div class="container-img" style="text-align:center;">
    <img src="assets/img/image1.png" style="width:300px;">

</div>

<!-- <iframe  src="https://viewer.diagrams.net/js/viewer-static.min.js" height="200" width="300"></iframe>
              <div class="mxgraph" data-mxgraph="{&quot;highlight&quot;:&quot;#0000ff&quot;,&quot;nav&quot;:true,&quot;resize&quot;:true,&quot;toolbar&quot;:&quot;zoom layers lightbox&quot;,&quot;edit&quot;:&quot;_blank&quot;,&quot;xml&quot;:&quot;&lt;mxfile host=\&quot;app.diagrams.net\&quot; modified=\&quot;2020-09-26T07:58:11.873Z\&quot; agent=\&quot;5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36\&quot; etag=\&quot;JN6BZ_SRGZv6n2d_b_8k\&quot; version=\&quot;13.7.5\&quot; type=\&quot;device\&quot;&gt;&lt;diagram id=\&quot;wXkmnr9B6Z_fIdXFDCrE\&quot; name=\&quot;Page-1\&quot;&gt;7Vpdc6IwFP01PNpBAqiPanV3Z7a7M+vO7vYxlQjZCYQNoWp//QYIH4FibatVW3xwkpObr3tvzgkMGpj6m08Mht4NdRDRDN3ZaOBaMwzLsMV/AmwzwAQgA1yGnQzql8ACPyAJ6hKNsYMixZBTSjgOVXBJgwAtuYJBxuhaNVtRos4aQhc1gMUSkib6Gzvcy9ChpZf4Z4RdL5+5r8sWH+bGEog86NB1BQIzDUwZpTwr+ZspIonvcr9k/eYtrcXCGAr4Ph3GsQ3877Nb6Pnxr+3DF97DqGfJtfFtvmHkiP3LKmXcoy4NIJmV6ITROHBQMqouaqXNV0pDAfYF+BdxvpXBhDGnAvK4T2Qr2mD+J+l+ZcnabaXleiNHTitbWcnWmSyudfsSimjMlmjHnvM0gsxFfIedWQRJJDeiPuJsK/oxRCDH9+o6oEwzt7ArIyEKMhjPCIwc9x6SWM6kGTYRy53cMVFyeeqTDIlCGChBtP/FSVZNVjTgvRX0MRFuHKcnAkMx9TSxhkHUixDDq3QkPbWN0pAlloYZbrIGjja8Bwl2g6yFoJWcXM5SLGema2NTm+h5YSYLo2lasLThtUTGczFQbjZstJrlUHKLwofZLvOd17JWzcm1hzlahDBNg7XgJTX/kq1OKaEs7Qvm6S/BMSEVXBc/2y5mu0dMuGJ39jWzRXYo+EzSoC2r65JT+jlReBU+GejHyi+94cMzPfnCw2xb6ZRUb6ttZbe0dgTGMPZkjOEpGcNoZYwk35MTDpcqPfzEvpBWQ/+G1uL/B/WTA5ZyQ0oLzQOu8g2BgauMB1lvMW7v1raMGzFOwUr1mdtYrcJUlmCq1kmbbFlBJMvYeWGkUpigpISAoJ/wR3AXhZVRRIiy/aiDN3hqp/WZEfeLiLhLMSXF6snyaPLsTMrDJNiF6eNIlUdg7KmP9tH0Ebx3fWyL8gF1E+ypm6NT6ibodLOpBaNBXQua1/rxrFRJiYAzkctiGdLAl65S0dSw4j39cUHd5adOMw91LftYegfMcxM8+73r3QF1zdxT14xT6trgUgJ6gsCAUwbGfOrC8UrpnuYCNM8LRindz9Pn9/CAemHKUH9T2B+cWhmGrfkaCnhJYBQpubFGEUcseOK64IszioPeHeWc+ln89StgLf3n31S6C9OLr9QCDutYF9W3esqaWPVnqvLNY0Fx/e6ZqnumevWr7uORxoXpa+1No2meWl5H5yKvzWz5kKdJUs5YFob55Xk0brwAm5f81HG0wtFtzug4+00Y+tFhL5ez62/Ljknaolp+k5W2VT5sA7P/&lt;/diagram&gt;&lt;/mxfile&gt;&quot;}"></div> -->
<!-- <script type="text/javascript"></script> -->
          
  इस वितरण प्रणाली की सहायता से ‘घर का किराना’ की आवश्यक सामग्री जनसामान्य के घर के पास उनकी पहुंच तक उपलब्ध कराई जाएगी| <br/>                                                                                                                                         
         </p>
        </div>


     <!--    <div class="row">

          <div class="col-lg-4 col-md-6">
            <div class="box">
              <h3>Free</h3>
              <h4><sup>$</sup>0<span> / month</span></h4>
              <ul>
                <li>Aida dere</li>
                <li>Nec feugiat nisl</li>
                <li>Nulla at volutpat dola</li>
                <li class="na">Pharetra massa</li>
                <li class="na">Massa ultricies mi</li>
              </ul>
              <div class="btn-wrap">
                <a href="#" class="btn-buy">Buy Now</a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mt-4 mt-md-0">
            <div class="box recommended">
              <span class="recommended-badge">Recommended</span>
              <h3>Business</h3>
              <h4><sup>$</sup>19<span> / month</span></h4>
              <ul>
                <li>Aida dere</li>
                <li>Nec feugiat nisl</li>
                <li>Nulla at volutpat dola</li>
                <li>Pharetra massa</li>
                <li class="na">Massa ultricies mi</li>
              </ul>
              <div class="btn-wrap">
                <a href="#" class="btn-buy">Buy Now</a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mt-4 mt-lg-0">
            <div class="box">
              <h3>Developer</h3>
              <h4><sup>$</sup>29<span> / month</span></h4>
              <ul>
                <li>Aida dere</li>
                <li>Nec feugiat nisl</li>
                <li>Nulla at volutpat dola</li>
                <li>Pharetra massa</li>
                <li>Massa ultricies mi</li>
              </ul>
              <div class="btn-wrap">
                <a href="#" class="btn-buy">Buy Now</a>
              </div>
            </div>
          </div>

        </div> -->

      </div>
    </section><!-- End Pricing Section -->

    <!-- ======= Faq Section ======= -->
   <!--  <section id="faq" class="faq">
      <div class="container-fluid">

        <div class="row">

          <div class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch  order-2 order-lg-1">

            <div class="content">
              <h3>Frequently Asked <strong>Questions</strong></h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Duis aute irure dolor in reprehenderit
              </p>
            </div>

            <div class="accordion-list">
              <ul>
                <li>
                  <a data-toggle="collapse" class="collapse" href="#accordion-list-1">Non consectetur a erat nam at lectus urna duis? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-1" class="collapse show" data-parent=".accordion-list">
                    <p>
                      Feugiat pretium nibh ipsum consequat. Tempus iaculis urna id volutpat lacus laoreet non curabitur gravida. Venenatis lectus magna fringilla urna porttitor rhoncus dolor purus non.
                    </p>
                  </div>
                </li>

                <li>
                  <a data-toggle="collapse" href="#accordion-list-2" class="collapsed">Feugiat scelerisque varius morbi enim nunc? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-2" class="collapse" data-parent=".accordion-list">
                    <p>
                      Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi. Id interdum velit laoreet id donec ultrices. Fringilla phasellus faucibus scelerisque eleifend donec pretium. Est pellentesque elit ullamcorper dignissim. Mauris ultrices eros in cursus turpis massa tincidunt dui.
                    </p>
                  </div>
                </li>

                <li>
                  <a data-toggle="collapse" href="#accordion-list-3" class="collapsed">Dolor sit amet consectetur adipiscing elit? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-3" class="collapse" data-parent=".accordion-list">
                    <p>
                      Eleifend mi in nulla posuere sollicitudin aliquam ultrices sagittis orci. Faucibus pulvinar elementum integer enim. Sem nulla pharetra diam sit amet nisl suscipit. Rutrum tellus pellentesque eu tincidunt. Lectus urna duis convallis convallis tellus. Urna molestie at elementum eu facilisis sed odio morbi quis
                    </p>
                  </div>
                </li>

              </ul>
            </div>

          </div>

          <div class="col-lg-5 align-items-stretch order-1 order-lg-2 img" style='background-image: url("assets/img/faq.jpg");'>&nbsp;</div>
        </div>

      </div>
    </section> --><!-- End Faq Section -->

    <!-- ======= Contact Section ======= -->
    <!-- End Contact Section -->

  </main>
</div><!-- End #main -->
  <!-- <div class="container"></div> -->


<?php

include 'footer.php';

?>
  <div id="preloader"></div>
  <a href="#" class="back-to-top"><i class="ri-arrow-up-line"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>